import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
import os
import pickle

class VectorDB:
    def __init__(self, db_path="./vectorstore/faiss_index"):
        self.db_path = db_path
        self.model = SentenceTransformer("all-MiniLM-L6-v2")
        self.index, self.metadata = self._load_index()

    def _load_index(self):
        if os.path.exists(self.db_path + ".index"):
            with open(self.db_path + "_meta.pkl", "rb") as f:
                metadata = pickle.load(f)
            index = faiss.read_index(self.db_path + ".index")
            return index, metadata
        else:
            index = faiss.IndexFlatL2(384)
            return index, []

    def add_documents(self, docs):
        embeddings = self.model.encode([doc['content'] for doc in docs])
        self.index.add(np.array(embeddings))
        self.metadata.extend(docs)
        self._save_index()

    def search(self, query, top_k=5):
        q_emb = self.model.encode([query])
        D, I = self.index.search(np.array(q_emb), top_k)
        results = [self.metadata[i] for i in I[0]]
        return results

    def _save_index(self):
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        faiss.write_index(self.index, self.db_path + ".index")
        with open(self.db_path + "_meta.pkl", "wb") as f:
            pickle.dump(self.metadata, f)

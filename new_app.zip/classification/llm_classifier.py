import openai
from config.config import Config

class LLMClassifier:
    def __init__(self):
        openai.api_key = Config.OPENAI_API_KEY

    def classify_document(self, text, categories=None):
        categories_str = ", ".join(categories) if categories else "General"
        prompt = f"Classify the following document into one of these categories: {categories_str}.\n\nDocument:\n{text[:1000]}"
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role":"system","content":"You are a document classification assistant."},
                      {"role":"user","content":prompt}]
        )
        return response['choices'][0]['message']['content'].strip()

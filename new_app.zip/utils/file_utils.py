import docx
import PyPDF2
import pandas as pd
from pptx import Presentation

def read_file_content(file_path):
    ext = file_path.split(".")[-1].lower()
    try:
        if ext == "pdf":
            return read_pdf(file_path)
        elif ext == "docx":
            return read_docx(file_path)
        elif ext == "txt":
            return read_txt(file_path)
        elif ext == "xlsx":
            return read_excel(file_path)
        elif ext == "pptx":
            return read_ppt(file_path)
    except Exception as e:
        print(f"Error reading {file_path}: {e}")
        return None

def read_pdf(file_path):
    text = ""
    with open(file_path, "rb") as f:
        reader = PyPDF2.PdfReader(f)
        for page in reader.pages:
            text += page.extract_text()
    return text

def read_docx(file_path):
    doc = docx.Document(file_path)
    return "\n".join([p.text for p in doc.paragraphs])

def read_txt(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()

def read_excel(file_path):
    df = pd.read_excel(file_path)
    return df.to_string()

def read_ppt(file_path):
    prs = Presentation(file_path)
    text = ""
    for slide in prs.slides:
        for shape in slide.shapes:
            if hasattr(shape, "text"):
                text += shape.text + "\n"
    return text

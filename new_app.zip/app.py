import streamlit as st
import pandas as pd
from config.config import Config
from ingestion.extractor import scan_repository
from classification.llm_classifier import LLMClassifier
from vectorstore.vector_db import VectorDB
from feedback.feedback_manager import FeedbackManager
import plotly.express as px

st.set_page_config(page_title="Smart File Classification & Update Assistant", layout="wide")
st.title("📂 Smart File Classification & Update Assistant")

classifier = LLMClassifier()
vector_db = VectorDB()
feedback_manager = FeedbackManager()

# Sidebar
st.sidebar.header("Options")
repo_option = st.sidebar.radio("Select repository type:", ["Local Repository", "Network Repository"])
upload_files = st.sidebar.file_uploader("Or Upload Documents", accept_multiple_files=True)

# Scan Repository
if st.sidebar.button("Scan Repository"):
    paths = Config.REPO_SCAN_PATHS
    documents = scan_repository(paths)
    st.success(f"Scanned {len(documents)} documents.")
    with st.spinner("Classifying documents..."):
        for doc in documents:
            category = classifier.classify_document(doc['content'])
            doc['category'] = category
        vector_db.add_documents(documents)
    st.success("✅ Documents classified and indexed successfully.")

# Upload Files
if upload_files:
    st.subheader("Uploaded Documents")
    for file in upload_files:
        content = file.read().decode('utf-8', errors='ignore')
        category = classifier.classify_document(content)
        vector_db.add_documents([{"path": file.name, "content": content, "category": category}])
        st.write(f"**{file.name}** - Category: {category}")

# Semantic Search
st.subheader("🔍 Semantic Search")
query = st.text_input("Enter search query:")
top_k = st.slider("Select number of top results:", min_value=1, max_value=10, value=5)
if query:
    results = vector_db.search(query, top_k=top_k)
    st.write("### Top Results")
    for res in results:
        st.markdown(f"- **{res['path']}** | Category: `{res.get('category', 'N/A')}`")

# Feedback
st.subheader("📝 Provide Feedback")
if vector_db.metadata:
    feedback_file = st.selectbox("Select document for feedback:", [r['path'] for r in vector_db.metadata])
    predicted_category = st.text_input("Predicted Category", value="Auto-filled by model")
    correct_category = st.text_input("Correct Category")
    if st.button("Submit Feedback"):
        feedback_manager.log_feedback(feedback_file, predicted_category, correct_category)
        st.success("Feedback logged successfully.")

# Analytics
st.subheader("📊 Feedback Analytics")
stats = feedback_manager.get_feedback_stats()
if stats:
    df_stats = pd.DataFrame(stats.items(), columns=["Category", "Accuracy"])
    fig = px.bar(df_stats, x="Category", y="Accuracy", color="Accuracy",
                 color_continuous_scale="Tealgrn", text="Accuracy")
    st.plotly_chart(fig)
else:
    st.info("No feedback yet. Submit feedback to see analytics.")

# Repository Summary
st.subheader("📁 Repository Summary")
if vector_db.metadata:
    df_repo = pd.DataFrame(vector_db.metadata)
    fig2 = px.pie(df_repo, names='category', title='Document Category Distribution')
    st.plotly_chart(fig2)
else:
    st.info("No documents indexed yet.")

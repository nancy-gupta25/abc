import os
from utils.file_utils import read_file_content

def scan_repository(path_list):
    documents = []
    for base_path in path_list:
        for root, _, files in os.walk(base_path):
            for file in files:
                if file.lower().endswith((".pdf", ".docx", ".txt", ".xlsx", ".pptx")):
                    file_path = os.path.join(root, file)
                    content = read_file_content(file_path)
                    if content:
                        documents.append({"path": file_path, "content": content})
    return documents

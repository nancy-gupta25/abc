import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    REPO_SCAN_PATHS = os.getenv("REPO_SCAN_PATHS", "./sample_repositories").split(";")
    VECTOR_DB_PATH = os.getenv("VECTOR_DB_PATH", "./vectorstore/faiss_index")

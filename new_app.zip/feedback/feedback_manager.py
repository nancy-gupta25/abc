import pandas as pd
import os

FEEDBACK_FILE = "./feedback/feedback.csv"
os.makedirs("./feedback", exist_ok=True)

class FeedbackManager:
    def __init__(self):
        if os.path.exists(FEEDBACK_FILE):
            self.df = pd.read_csv(FEEDBACK_FILE)
        else:
            self.df = pd.DataFrame(columns=["file_path","predicted_category","correct_category"])

    def log_feedback(self, file_path, predicted, correct):
        self.df = pd.concat([self.df, pd.DataFrame([{
            "file_path": file_path,
            "predicted_category": predicted,
            "correct_category": correct
        }])], ignore_index=True)
        self.df.to_csv(FEEDBACK_FILE, index=False)

    def get_feedback_stats(self):
        if self.df.empty:
            return {}
        return self.df.groupby("predicted_category").apply(
            lambda x: (x['predicted_category']==x['correct_category']).mean()
        ).to_dict()
